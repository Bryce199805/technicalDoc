#!/usr/bin/env bash

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLI_ARCHIVE="$SCRIPT_DIR/cli-bin.tar.gz"
INSTALL_BIN_DIR="$HOME/.local/bin"
TEMP_DIR=""

cleanup() {
    if [ -n "$TEMP_DIR" ] && [ -d "$TEMP_DIR" ]; then
        rm -rf -- "$TEMP_DIR"
    fi
}
trap cleanup EXIT

echo
echo "============================================"
echo "    Linux CLI Tools 一键安装"
echo "============================================"
echo

if [ ! -f "$CLI_ARCHIVE" ]; then
    print_error "找不到二进制包: $CLI_ARCHIVE"
    exit 1
fi

# 在系统临时目录解包，不要求安装包所在目录可写。
print_info "安装 CLI 工具到 $INSTALL_BIN_DIR ..."
TEMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/cli-tools.XXXXXX")"
mkdir -p "$INSTALL_BIN_DIR"
tar -xzf "$CLI_ARCHIVE" -C "$TEMP_DIR"

if [ ! -d "$TEMP_DIR/cli-bin" ]; then
    print_error "二进制包结构不正确：缺少 cli-bin 目录"
    exit 1
fi

cp "$TEMP_DIR/cli-bin/"* "$INSTALL_BIN_DIR/"
chmod +x "$INSTALL_BIN_DIR/"*
export PATH="$INSTALL_BIN_DIR:$PATH"
print_success "CLI 工具安装完成"

if ! command -v git &> /dev/null; then
    print_error "未找到 git，无法安装 Oh My Zsh"
    exit 1
fi

if [ ! -d "$HOME/.oh-my-zsh" ]; then
    print_info "安装 Oh My Zsh 到 $HOME/.oh-my-zsh ..."
    git clone https://gitee.com/mirrors/oh-my-zsh.git "$HOME/.oh-my-zsh"
    print_success "Oh My Zsh 安装完成"
else
    print_warning "Oh My Zsh 已安装，跳过"
fi

print_info "配置 zsh..."
bash "$SCRIPT_DIR/configure-zsh.sh"

echo
print_success "全部安装完成!"
echo "请运行 'exec zsh' 或重新打开终端。"
